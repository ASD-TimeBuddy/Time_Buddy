import { Text } from '@chakra-ui/react';

const Calendar = () => <Text>Coming soon...</Text>;

export default Calendar;
